package dataviewer2;

import javax.swing.JOptionPane;

public class MenuHandler {
    public void handleKeyPress(int key, DataViewerApp app) {
        boolean needsUpdate = false;
        boolean needsUpdatePlotData = false;
        if (key == 'Q') {
            System.exit(0);
        } else if (app.getGUI().getGuiMode() == DataViewerGUI.GUI_MODE_MAIN_MENU) {
            if (key == 'P') {
                app.getGUI().setGuiMode(DataViewerGUI.GUI_MODE_DATA);
                if (app.getDataPlotter().getPlotData().isEmpty()) {
                    needsUpdatePlotData = true;
                }
                needsUpdate = true;
            } else if (key == 'C') {
                Object selectedValue = JOptionPane.showInputDialog(null,
                        "Choose a Country", "Input",
                        JOptionPane.INFORMATION_MESSAGE, null,
                        app.getDataLoader().getDataCountries().toArray(), app.getGUI().getSelectedCountry());
                if (selectedValue != null) {
                    app.getGUI().setSelectedCountry((String) selectedValue);
                    try {
                        app.getDataLoader().loadData();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    needsUpdate = true;
                    needsUpdatePlotData = true;
                }
            } else if (key == 'T') {
                Object selectedValue = JOptionPane.showInputDialog(null,
                        "Choose a State", "Input",
                        JOptionPane.INFORMATION_MESSAGE, null,
                        app.getDataLoader().getDataStates().toArray(), app.getGUI().getSelectedState());
                if (selectedValue != null) {
                    app.getGUI().setSelectedState((String) selectedValue);
                    needsUpdate = true;
                    needsUpdatePlotData = true;
                }
            } else if (key == 'S') {
                Object selectedValue = JOptionPane.showInputDialog(null,
                        "Choose the start year", "Input",
                        JOptionPane.INFORMATION_MESSAGE, null,
                        app.getDataLoader().getDataYears().toArray(), app.getGUI().getSelectedStartYear());
                if (selectedValue != null) {
                    Integer year = (Integer) selectedValue;
                    if (year > app.getGUI().getSelectedEndYear()) {
                        System.out.println("Error: Start year must not be after end year.");
                    } else {
                        app.getGUI().setSelectedStartYear(year);
                        needsUpdate = true;
                        needsUpdatePlotData = true;
                    }
                }
            } else if (key == 'E') {
                Object selectedValue = JOptionPane.showInputDialog(null,
                        "Choose the end year", "Input",
                        JOptionPane.INFORMATION_MESSAGE, null,
                        app.getDataLoader().getDataYears().toArray(), app.getGUI().getSelectedEndYear());
                if (selectedValue != null) {
                    Integer year = (Integer) selectedValue;
                    if (year < app.getGUI().getSelectedStartYear()) {
                        System.out.println("Error: End year must not be before start year.");
                    } else {
                        app.getGUI().setSelectedEndYear(year);
                        needsUpdate = true;
                        needsUpdatePlotData = true;
                    }
                }
            } else if (key == 'V') {
                Object selectedValue = JOptionPane.showInputDialog(null,
                        "Choose the visualization mode", "Input",
                        JOptionPane.INFORMATION_MESSAGE, null,
                        new String[]{"Raw", "Extrema (within 10% of min/max)"}, app.getGUI().getSelectedVisualization());
                if (selectedValue != null) {
                    app.getGUI().setSelectedVisualization((String) selectedValue);
                    needsUpdate = true;
                }
            }
        } else if (app.getGUI().getGuiMode() == DataViewerGUI.GUI_MODE_DATA) {
            if (key == 'M') {
                app.getGUI().setGuiMode(DataViewerGUI.GUI_MODE_MAIN_MENU);
                needsUpdate = true;
            }
        }
        if (needsUpdatePlotData) {
            app.getDataPlotter().updatePlotData(app.getDataLoader(), app.getGUI().getSelectedState(), app.getGUI().getSelectedStartYear(), app.getGUI().getSelectedEndYear());
        }
        if (needsUpdate) {
            app.update();
        }
    }
}
