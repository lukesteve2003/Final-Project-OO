package dataviewer2;

import java.io.FileNotFoundException;
import java.util.SortedSet;
import java.util.TreeSet;

import edu.du.dudraw.Draw;
import edu.du.dudraw.DrawListener;

public class DataViewerApp implements DrawListener {
    private final String m_dataFile;
    private DataLoader m_dataLoader;
    private DataPlotter m_dataPlotter;
    private MenuHandler m_menuHandler;
    private DataViewerGUI m_gui;

    public DataViewerApp(String dataFile) throws FileNotFoundException {
        m_dataFile = dataFile;
        m_dataLoader = new DataLoader(m_dataFile);
        m_dataPlotter = new DataPlotter();
        m_menuHandler = new MenuHandler();
        m_gui = new DataViewerGUI(this);

        m_gui.initialize();
        m_dataLoader.loadData();
        m_gui.update();
    }

    @Override
    public void update() {
        m_gui.update();
    }

    @Override
    public void keyPressed(int key) {
        m_menuHandler.handleKeyPress(key, this);
    }

    @Override
    public void keyReleased(int key) {}

    @Override
    public void keyTyped(char key) {}

    @Override
    public void mouseClicked(double x, double y) {}

    @Override
    public void mouseDragged(double x, double y) {}

    @Override
    public void mousePressed(double x, double y) {}

    @Override
    public void mouseReleased(double x, double y) {}

    public DataLoader getDataLoader() {
        return m_dataLoader;
    }

    public DataPlotter getDataPlotter() {
        return m_dataPlotter;
    }

    public DataViewerGUI getGUI() {
        return m_gui;
    }
}
