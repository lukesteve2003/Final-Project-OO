package dataviewer2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.SortedSet;
import java.util.TreeSet;

public class DataLoader {
    private final String m_dataFile;
    private List<List<Object>> m_dataRaw;
    private SortedSet<String> m_dataStates;
    private SortedSet<String> m_dataCountries;
    private SortedSet<Integer> m_dataYears;

    public DataLoader(String dataFile) {
        m_dataFile = dataFile;
        m_dataRaw = new ArrayList<>();
        m_dataStates = new TreeSet<>();
        m_dataCountries = new TreeSet<>();
        m_dataYears = new TreeSet<>();
    }

    public void loadData() throws FileNotFoundException {
        try (Scanner scanner = new Scanner(new File(m_dataFile))) {
            boolean skipFirst = true;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!skipFirst) {
                    List<Object> record = getRecordFromLine(line);
                    if (record != null) {
                        m_dataRaw.add(record);
                    }
                } else {
                    skipFirst = false;
                }
            }
        }
    }

    private List<Object> getRecordFromLine(String line) {
        List<String> rawValues = new ArrayList<>();
        try (Scanner rowScanner = new Scanner(line)) {
            rowScanner.useDelimiter(",");
            while (rowScanner.hasNext()) {
                rawValues.add(rowScanner.next());
            }
        }
        if (rawValues.size() != 5) {
            return null;
        }
        try {
            List<Object> values = new ArrayList<>(4);
            Integer year = parseYear(rawValues.get(0));
            if (year == null) {
                return null;
            }
            values.add(year);
            Integer month = parseMonth(rawValues.get(0));
            if (month == null) {
                return null;
            }
            values.add(month);
            values.add(Double.parseDouble(rawValues.get(1)));
            values.add(rawValues.get(3));
            m_dataStates.add(rawValues.get(3));
            m_dataCountries.add(rawValues.get(4));
            m_dataYears.add(year);
            return values;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Integer parseYear(String dateString) {
        String[] parts = dateString.split("/");
        if (parts.length == 3) {
            return Integer.parseInt(parts[2]);
        }
        return null;
    }

    private Integer parseMonth(String dateString) {
        String[] parts = dateString.split("/");
        if (parts.length == 3) {
            return Integer.parseInt(parts[0]);
        }
        return null;
    }

    public List<List<Object>> getDataRaw() {
        return m_dataRaw;
    }

    public SortedSet<String> getDataStates() {
        return m_dataStates;
    }

    public SortedSet<String> getDataCountries() {
        return m_dataCountries;
    }

    public SortedSet<Integer> getDataYears() {
        return m_dataYears;
    }
}
