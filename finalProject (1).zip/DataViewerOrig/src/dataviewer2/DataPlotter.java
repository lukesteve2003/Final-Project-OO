package dataviewer2;

import java.awt.Color;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

public class DataPlotter {
    private TreeMap<Integer, SortedMap<Integer, Double>> m_plotData;
    private TreeMap<Integer, Double> m_plotMonthlyMaxValue;
    private TreeMap<Integer, Double> m_plotMonthlyMinValue;

    public DataPlotter() {
        m_plotData = new TreeMap<>();
        m_plotMonthlyMaxValue = new TreeMap<>();
        m_plotMonthlyMinValue = new TreeMap<>();
    }

    public void updatePlotData(DataLoader dataLoader, String selectedState, int selectedStartYear, int selectedEndYear) {
        for (int month = 1; month <= 12; month++) {
            m_plotData.put(month, new TreeMap<>());
        }
        for (int i = 1; i <= 12; i++) {
            m_plotMonthlyMaxValue.put(i, Double.MIN_VALUE);
            m_plotMonthlyMinValue.put(i, Double.MAX_VALUE);
        }
        for (List<Object> rec : dataLoader.getDataRaw()) {
            String state = (String) rec.get(3);
            Integer year = (Integer) rec.get(0);
            if (state.equals(selectedState) && year >= selectedStartYear && year <= selectedEndYear) {
                Integer month = (Integer) rec.get(1);
                Double value = (Double) rec.get(2);
                if (value < m_plotMonthlyMinValue.get(month)) {
                    m_plotMonthlyMinValue.put(month, value);
                }
                if (value > m_plotMonthlyMaxValue.get(month)) {
                    m_plotMonthlyMaxValue.put(month, value);
                }
                m_plotData.get(month).put(year, value);
            }
        }
    }

    public TreeMap<Integer, SortedMap<Integer, Double>> getPlotData() {
        return m_plotData;
    }

    public TreeMap<Integer, Double> getPlotMonthlyMaxValue() {
        return m_plotMonthlyMaxValue;
    }

    public TreeMap<Integer, Double> getPlotMonthlyMinValue() {
        return m_plotMonthlyMinValue;
    }

    public Color getDataColor(Double value, boolean doGrayscale) {
        if (value == null) {
            return null;
        }
        double pct = (value + 10) / 40;
        if (pct > 1.0) {
            pct = 1.0;
        } else if (pct < 0.0) {
            pct = 0.0;
        }
        int r, g, b;
        if (!doGrayscale) {
            r = (int) (255.0 * pct);
            g = 0;
            b = (int) (255.0 * (1.0 - pct));
        } else {
            r = g = b = (int) (255.0 * pct);
        }
        return new Color(r, g, b);
    }
}
