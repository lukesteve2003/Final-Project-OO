package dataviewer2;

import edu.du.dudraw.Draw;

import java.awt.Color;
import java.util.SortedMap;

public class DataViewerGUI {
    public static final int GUI_MODE_MAIN_MENU = 0;
    public static final int GUI_MODE_DATA = 1;

    private final DataViewerApp m_app;
    private Draw m_window;
    private int m_guiMode = GUI_MODE_MAIN_MENU;
    private String m_selectedCountry = "United States";
    private String m_selectedState;
    private int m_selectedStartYear;
    private int m_selectedEndYear;
    private String m_selectedVisualization = "Raw";

    public DataViewerGUI(DataViewerApp app) {
        m_app = app;
    }

    public void initialize() {
        m_window = new Draw("DataViewer Application");
        m_window.setCanvasSize(1320, 720);
        m_window.enableDoubleBuffering();
        m_window.addListener(m_app);
    }

    public void update() {
        if (m_guiMode == GUI_MODE_MAIN_MENU) {
            drawMainMenu();
        } else if (m_guiMode == GUI_MODE_DATA) {
            drawData();
        }
        m_window.show();
    }

    private void drawMainMenu() {
        m_window.clear(Color.WHITE);
        String[] menuItems = {
                "Type the menu number to select that option:",
                "",
                String.format("C     Set country: [%s]", m_selectedCountry),
                String.format("T     Set state: [%s]", m_selectedState),
                String.format("S     Set start year [%d]", m_selectedStartYear),
                String.format("E     Set end year [%d]", m_selectedEndYear),
                String.format("V     Set visualization [%s]", m_selectedVisualization),
                String.format("P     Plot data"),
                String.format("Q     Quit"),
        };
        double yCoord = 90.0;
        for (String item : menuItems) {
            m_window.textLeft(40.0, yCoord, item);
            yCoord -= 5.0;
        }
    }

    private void drawData() {
        m_window.clear(Color.LIGHT_GRAY);
        m_window.setPenColor(Color.WHITE);
        m_window.filledRectangle(660.0, 360.0, 660.0, 360.0);
        m_window.setPenColor(Color.BLACK);

        double nCols = 12;
        double nRows = m_selectedEndYear - m_selectedStartYear + 1;
        double cellWidth = 1320.0 / nCols;
        double cellHeight = 720.0 / nRows;

        boolean extremaVisualization = m_selectedVisualization.equals("Extrema (within 10% of min/max)");

        for (int month = 1; month <= 12; month++) {
            double fullRange = m_app.getDataPlotter().getPlotMonthlyMaxValue().get(month) - m_app.getDataPlotter().getPlotMonthlyMinValue().get(month);
            double extremaMinBound = m_app.getDataPlotter().getPlotMonthlyMinValue().get(month) + 0.1 * fullRange;
            double extremaMaxBound = m_app.getDataPlotter().getPlotMonthlyMaxValue().get(month) - 0.1 * fullRange;

            double lineX = (month - 1.0) * cellWidth;
            m_window.line(lineX, 0.0, lineX, 720.0);
            m_window.text(lineX + cellWidth / 2.0, -25.0, new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}[month - 1]);

            SortedMap<Integer, Double> monthData = m_app.getDataPlotter().getPlotData().get(month);
            for (int year = m_selectedStartYear; year <= m_selectedEndYear; year++) {
                if (monthData.containsKey(year)) {
                    Double value = monthData.get(year);
                    double x = (month - 1.0) * cellWidth + 0.5 * cellWidth;
                    double y = (year - m_selectedStartYear) * cellHeight + 0.5 * cellHeight;
                    Color cellColor;
                    if (extremaVisualization && value > extremaMinBound && value < extremaMaxBound) {
                        cellColor = m_app.getDataPlotter().getDataColor(value, true);
                    } else if (extremaVisualization) {
                        cellColor = value >= extremaMaxBound ? Color.RED : Color.BLUE;
                    } else {
                        cellColor = m_app.getDataPlotter().getDataColor(value, false);
                    }
                    m_window.setPenColor(cellColor);
                    m_window.filledRectangle(x, y, cellWidth / 2.0, cellHeight / 2.0);
                }
            }
        }

        for (int i = 0; i < 6; i++) {
            int year = (int) Math.round(i * (m_selectedEndYear - m_selectedStartYear) / 5.0 + m_selectedStartYear);
            String text = String.format("%4d", year);
            m_window.textRight(0.0, i * 144.0, text);
            m_window.textLeft(1320.0, i * 144.0, text);
        }

        m_window.rectangle(660.0, 360.0, 660.0, 360.0);
        String title = String.format("%s, %s from %d to %d. Press 'M' for Main Menu.  Press 'Q' to Quit.",
                m_selectedState, m_selectedCountry, m_selectedStartYear, m_selectedEndYear);
        m_window.text(660.0, 745.0, title);
    }

    public int getGuiMode() {
        return m_guiMode;
    }

    public void setGuiMode(int guiMode) {
        m_guiMode = guiMode;
    }

    public String getSelectedCountry() {
        return m_selectedCountry;
    }

    public void setSelectedCountry(String selectedCountry) {
        m_selectedCountry = selectedCountry;
    }

    public String getSelectedState() {
        return m_selectedState;
    }

    public void setSelectedState(String selectedState) {
        m_selectedState = selectedState;
    }

    public int getSelectedStartYear() {
        return m_selectedStartYear;
    }

    public void setSelectedStartYear(int selectedStartYear) {
        m_selectedStartYear = selectedStartYear;
    }

    public int getSelectedEndYear() {
        return m_selectedEndYear;
    }

    public void setSelectedEndYear(int selectedEndYear) {
        m_selectedEndYear = selectedEndYear;
    }

    public String getSelectedVisualization() {
        return m_selectedVisualization;
    }

    public void setSelectedVisualization(String selectedVisualization) {
        m_selectedVisualization = selectedVisualization;
    }
}
